RE/flex library source code used by ugrep

Source: https://github.com/Genivia/RE-flex
