// This file is used to ensure a LIB is created even when no source is present.
