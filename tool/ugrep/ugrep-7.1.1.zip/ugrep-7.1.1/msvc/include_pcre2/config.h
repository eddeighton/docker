#define PCRE2_STATIC
#define PCRE2_CODE_UNIT_WIDTH 8
#define SUPPORT_JIT
#define SUPPORT_UNICODE
//#define LINK_SIZE 3 // Support extra-large regular expression patterns?
#include <config.h.generic>
